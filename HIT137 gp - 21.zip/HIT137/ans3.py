import turtle

# Recursive function to draw the tree
def draw_branch(length, depth, left_angle, right_angle, reduction_factor):
    if depth == 0 or length < 1:
        return

    turtle.forward(length)
    
    # Left branch
    turtle.left(left_angle)
    draw_branch(length * reduction_factor, depth - 1, left_angle, right_angle, reduction_factor)
    
    # Return to original angle and draw right branch
    turtle.right(left_angle + right_angle)
    draw_branch(length * reduction_factor, depth - 1, left_angle, right_angle, reduction_factor)
    
    # Restore the original heading and position
    turtle.left(right_angle)
    turtle.backward(length)

# --- User Input ---
try:
    left_angle = float(input("Enter left branch angle (degrees): "))
    right_angle = float(input("Enter right branch angle (degrees): "))
    start_length = float(input("Enter starting branch length (e.g., 100): "))
    max_depth = int(input("Enter recursion depth (e.g., 5): "))
    reduction_factor = float(input("Enter branch length reduction factor (e.g., 0.7): "))

    # --- Setup Turtle ---
    turtle.speed('fastest')
    turtle.left(90)  # Point upwards
    turtle.penup()
    turtle.goto(0, -250)  # Start from bottom of screen
    turtle.pendown()
    turtle.color("green")

    # --- Start Drawing ---
    draw_branch(start_length, max_depth, left_angle, right_angle, reduction_factor)

    turtle.done()

except ValueError:
    print("Please enter valid numeric values for all parameters.")
