import string

def shift_char(c, shift):
    # Shift a character within the alphabet with wrapping
    if c.islower():
        return chr((ord(c) - ord('a') + shift) % 26 + ord('a'))
    elif c.isupper():
        return chr((ord(c) - ord('A') + shift) % 26 + ord('A'))
    return c

def encrypt_text(text, n, m):
    encrypted = ''
    for c in text:
        if c in string.ascii_lowercase:
            if c <= 'm':
                shift = n * m
            else:
                shift = -(n + m)
            encrypted += shift_char(c, shift)
        elif c in string.ascii_uppercase:
            if c <= 'M':
                shift = -n
            else:
                shift = m * m
            encrypted += shift_char(c, shift)
        else:
            encrypted += c
    return encrypted

def decrypt_text(text, n, m):
    decrypted = ''
    for c in text:
        if c in string.ascii_lowercase:
            if c <= 'm':
                shift = -(n * m)
            else:
                shift = n + m
            decrypted += shift_char(c, shift)
        elif c in string.ascii_uppercase:
            if c <= 'M':
                shift = n
            else:
                shift = -(m * m)
            decrypted += shift_char(c, shift)
        else:
            decrypted += c
    return decrypted

def check_correctness(original, decrypted):
    return original == decrypted

# Input from user
n = int(input("Enter value for n: "))
m = int(input("Enter value for m: "))

# Read original text
with open("HIT137\\raw_text.txt", "r") as f:
    original_text = f.read()

# Encrypt and write to file
encrypted_text = encrypt_text(original_text, n, m)
with open("HIT137\\encrypted_text.txt", "w") as f:
    f.write(encrypted_text)

# Optional: Decrypt and check
decrypted_text = decrypt_text(encrypted_text, n, m)
if check_correctness(original_text, decrypted_text):
    print("Decryption verified successfully!")
else:
    print("Decryption failed. There is a mismatch.")
