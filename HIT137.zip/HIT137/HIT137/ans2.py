import os
import csv
from collections import defaultdict

# Folder containing CSVs
FOLDER = "HIT137\\temperature_data"

# Output paths
AVG_TEMP_FILE = "HIT137\\average_temp.txt"
RANGE_FILE = "HIT137\\largest_temp_range_station.txt"
WARM_COOL_FILE ="HIT137\\warmest_and_coolest_station.txt"

# Season-month mapping
season_months = {
    "Summer": ["December", "January", "February"],
    "Autumn": ["March", "April", "May"],
    "Winter": ["June", "July", "August"],
    "Spring": ["September", "October", "November"]
}

# Aggregate seasonal and station data
seasonal_totals = defaultdict(list)
station_temps = {}

skipped_rows = 0

for filename in os.listdir(FOLDER):
    if filename.startswith("stations_group_") and filename.endswith(".csv"):
        file_path = os.path.join(FOLDER, filename)
        with open(file_path, newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row_num, row in enumerate(reader, 1):
                try:
                    station = row["STATION_NAME"].strip()
                    monthly_temps = []

                    for month in [
                        "January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"
                    ]:
                        val = row[month].strip()
                        temp = float(val) if val else None
                        if temp is not None:
                            monthly_temps.append(temp)

                    # Save monthly temps per station
                    station_temps[station] = monthly_temps

                    # Group by season
                    for season, months in season_months.items():
                        for month in months:
                            val = row.get(month, "").strip()
                            if val:
                                seasonal_totals[season].append(float(val))
                except Exception as e:
                    skipped_rows += 1
                    print(f"Error in file {filename}, row {row_num}: {e}")

# Step 1: Write average seasonal temps
with open(AVG_TEMP_FILE, "w") as f:
    f.write("Average Seasonal Temperatures (°C):\n")
    for season in ["Summer", "Autumn", "Winter", "Spring"]:
        temps = seasonal_totals[season]
        if temps:
            avg = sum(temps) / len(temps)
            f.write(f"{season}: {avg:.2f}\n")
        else:
            f.write(f"{season}: No data available\n")

# Step 2: Largest temperature range
max_range = 0
stations_with_max_range = []

for station, temps in station_temps.items():
    if temps:
        temp_range = max(temps) - min(temps)
        if temp_range > max_range:
            max_range = temp_range
            stations_with_max_range = [station]
        elif temp_range == max_range:
            stations_with_max_range.append(station)

with open(RANGE_FILE, "w") as f:
    f.write(f"Largest temperature range: {max_range:.2f}°C\n")
    f.write("Station(s):\n")
    for station in stations_with_max_range:
        f.write(f"{station}\n")

# Step 3: Warmest and coolest stations
warmest_avg = float("-inf")
coolest_avg = float("inf")
warmest_stations = []
coolest_stations = []

for station, temps in station_temps.items():
    if temps:
        avg_temp = sum(temps) / len(temps)
        if avg_temp > warmest_avg:
            warmest_avg = avg_temp
            warmest_stations = [station]
        elif avg_temp == warmest_avg:
            warmest_stations.append(station)

        if avg_temp < coolest_avg:
            coolest_avg = avg_temp
            coolest_stations = [station]
        elif avg_temp == coolest_avg:
            coolest_stations.append(station)

with open(WARM_COOL_FILE, "w") as f:
    f.write(f"Warmest average temperature: {warmest_avg:.2f}°C\n")
    f.write("Warmest station(s):\n")
    for station in warmest_stations:
        f.write(f"{station}\n")

    f.write(f"\nCoolest average temperature: {coolest_avg:.2f}°C\n")
    f.write("Coolest station(s):\n")
    for station in coolest_stations:
        f.write(f"{station}\n")

print(f"Done! Skipped {skipped_rows} row(s) with issues.")
